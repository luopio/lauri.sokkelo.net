import processing.core.*; import processing.core.*; import processing.video.*; import java.applet.*; import java.awt.*; import java.awt.image.*; import java.awt.event.*; import java.io.*; import java.net.*; import java.text.*; import java.util.*; import java.util.zip.*; import javax.sound.midi.*; import javax.sound.midi.spi.*; import javax.sound.sampled.*; import javax.sound.sampled.spi.*; import java.util.regex.*; import javax.xml.parsers.*; import javax.xml.transform.*; import javax.xml.transform.dom.*; import javax.xml.transform.sax.*; import javax.xml.transform.stream.*; import org.xml.sax.*; import org.xml.sax.ext.*; import org.xml.sax.helpers.*; public class neon_play extends PApplet {


class FlickrUploader {
  String APIKEY = "db5d5845a512ffa2bd8bea2007f99f0c";
  String APISECRET = "4462e701e7496444";
  String APPNAME = "neon_play";
  
}


class Graffiti {
  PApplet main;
  PImage buffer;
  int defaultColor;
  PImage brush;
  int previousX, previousY;
  
  public Graffiti(PApplet main) {
   this.main = main;
   buffer = createImage(main.width, main.height, ARGB);
   brush = loadImage("brush-round.png");
   defaultColor = color(255, 255, 255);
  }
  public void draw(int x, int y) {
//    buffer.loadPixels();
//    buffer.pixels[y*buffer.width + x] = defaultColor;
//    buffer.updatePixels();
    buffer.blend(brush, 0, 0, 20, 20, x, y, 20, 20, BLEND);
  }
  public void show() {
    main.image(buffer, 0, 0);
  }
}

class ImageSnapper {
 
  Capture video;
  PApplet main;
  PImage dblBuffer;
  PImage[] rememberedFrames;
  int rememberedFramesAmount = 5;
  int curFrameIndex;
  int[] alphaMask;
  
  public ImageSnapper(PApplet mainProcessingThread) {
    main = mainProcessingThread;
    main.loadPixels();
    dblBuffer = createImage(main.width, main.height, ARGB);
    video = new Capture(main, main.width, main.height, 24);
    alphaMask = new int[video.height * video.width];
    rememberedFrames = new PImage[ rememberedFramesAmount ];
    for(int i = 0; i < rememberedFramesAmount; i++) {
      rememberedFrames[i] = createImage(video.width, video.height, ARGB);
    }
    curFrameIndex = 0;
  }
  
  public ImageSnapper shoot() {
    if(video.available()) {
      video.read();
    } 
    return this;
  }
  
  public ImageSnapper reduceColors(int factor) {
    video.loadPixels();
//    video.filter(INVERT);
//    video.filter(POSTERIZE, 10);
    
    for(int i = 0; i < video.width * video.height; i++) {
      int c = video.pixels[i];
      int r = (c >> 16) & 0xFF;
      int g = (c >> 8) & 0xFF;
      int b = c & 0xFF;
      r = round( r / factor * factor );
      g = round( g / factor * factor );
      b = round( b / factor * factor );
      if((r + g + b) > 30) {
        video.pixels[i] = color(r, g, b);
        alphaMask[i] = abs(r+b+g - 255);
      } else { 
        video.pixels[i] = 0xFF000000; // make it transparent
        alphaMask[i] = 0;
      }
     }

    return this;
  }
  
  public ImageSnapper show() {
    dblBuffer.loadPixels();
    video.loadPixels();
    for(int i = 0; i < video.width * video.height; i++) {
      dblBuffer.pixels[i] = video.pixels[i];
    }
    dblBuffer.updatePixels();
    dblBuffer.mask(alphaMask);
//    dblBuffer.filter(POSTERIZE, 60); // does the same thing as reducecolors without the alphamask and ability to 
// tweak the colors
    main.image(dblBuffer, 0, 0);

    return this;
  }
  
  public PImage rememberImage() {
    PImage curFrame = rememberedFrames[curFrameIndex];
    curFrameIndex++;
    if(curFrameIndex == 5) curFrameIndex = 0;
    curFrame.loadPixels();
    dblBuffer.loadPixels();
    
    for(int i = 0; i < video.width * video.height; i++ )
      curFrame.pixels[i] = dblBuffer.pixels[i];
    //arraycopy(video.pixels, newImg.pixels);
    curFrame.updatePixels();
    return curFrame;
  }
}



ImageSnapper snap;
Graffiti graf;
int colorFactor = 50;

public void setup() {
  size(640, 480);
  snap = new ImageSnapper(this);
  graf = new Graffiti(this);
  background(0);
  PFont font = loadFont("Arcade-48.vlw");
  textFont(font, 32);
}

public void draw() {
  
  // empty the screen with a black background
  fill(0);
  rect(0, 0, width, height);
  
  // show a message
  fill(230);
  text("mlab 08 rulz", 15, 30);
  
  // blit all the remembered frames
  for(int i = 0; i < snap.rememberedFramesAmount; i++) {
    image(snap.rememberedFrames[i], 0, 0);
  }
  
  // record what we see
  snap.shoot();
  snap.reduceColors(colorFactor);
  
  // put the image on screen
  snap.show();
  
  graf.show();

// snap.toGrayScale();
// tint(255, 128);

}

public void keyPressed() {
  println("( * ) taking snapsnot");
  snap.rememberImage();
}


public void mouseDragged() {
  graf.draw(mouseX, mouseY);  
}
  static public void main(String args[]) {     PApplet.main(new String[] { "neon_play" });  }}