import os, appuifw, audio, graphics, e32
import World
from audio import Sound

fulname = appuifw.app.full_name()
if fulname.lower().find('python') != -1:
    cwd = 'e:\\python'
else:
    cwd = os.getcwd()
gfx_dir = os.path.join(cwd, 'gfx')

grass_field = {'starting_position': (330, 990),
               'checkpoints': [(320,938,337,1040), (550, 938, 608, 1040), (683, 735, 732, 822), (490, 386, 602, 425), (783, 333, 820, 430), (989, 127, 1090, 166),
                               (500, 3, 600, 122), (217, 292, 329, 353), (292, 553, 331, 656), (1, 553, 109, 580), (52, 930, 194, 987)],
               # 'track_order': [23, 24, 19, 18, 13, 8, 9, 10, 5, 4, 3, 2, 7, 12, 11, 16, 21, 22],
               
               'number_image_paths': [ os.path.join(gfx_dir, png) for png in [ 'char_0.png', 'char_1.png', 'char_2.png',
                                      'char_3.png', 'char_4.png', 'char_5.png',
                                      'char_6.png', 'char_7.png', 'char_8.png',
                                      'char_9.png', 'char_..png' ] ], 
               
               'track_order':  [22, 23, 24, 19, 18, 13, 8, 9, 10, 5, 4, 3, 2, 7, 12, 11, 16, 21], 
               
               'gfx': { 'world_image': os.path.join(gfx_dir, 'katu_1.png'),
                    'world_image_mask' : os.path.join(gfx_dir, 'katu_1_mask.png'),
                    'scoreboard_image': os.path.join(gfx_dir, 'pallo_scoreboard.png'),
                    'title_image' : os.path.join(gfx_dir, 'title_screen.png'),
                    'loading_image' : os.path.join(gfx_dir, 'penalti_loading.png'),
                    #'ball_frames': [os.path.join(gfx_dir, png) for png in ['pallo1.png', 'pallo2.png', 'pallo3.png', 'pallo4.png']],
                    'ball_frames': [os.path.join(gfx_dir, png) for png in ['pallo1_alt.png', 'pallo2_alt.png', 'pallo3_alt.png', 'pallo4_alt.png']],
                    'ball_death_frames': [os.path.join(gfx_dir, png) for png in ['pallo1.png', 'pallo2.png', 'pallo3.png', 'pallo4.png']],
                    'ball_mask': os.path.join(gfx_dir, 'pallo_mask.png')}
               }

grass_field_2 = {'starting_position': (330, 990),
               'checkpoints': [(320,938,337,1040),(881,932,933,1046),(876,491,921,605),(274,440,385,495),(931,218,1044,274),(52,163,164,202),(176,933,208,1044)],
               # 'track_order': [23, 24, 19, 18, 13, 8, 9, 10, 5, 4, 3, 2, 7, 12, 11, 16, 21, 22],
               
               'number_image_paths': [ os.path.join(gfx_dir, png) for png in [ 'char_0.png', 'char_1.png', 'char_2.png',
                                      'char_3.png', 'char_4.png', 'char_5.png',
                                      'char_6.png', 'char_7.png', 'char_8.png',
                                      'char_9.png', 'char_..png' ] ], 
               
               'track_order':  [22, 23, 24, 25, 20, 15, 14, 13, 12, 7, 8, 9, 10, 5, 4, 3, 2, 1, 6, 11, 16, 21], 
               
               'gfx': { 'world_image': os.path.join(gfx_dir, 'katu_2.png'),
                    'world_image_mask' : os.path.join(gfx_dir, 'katu_2_mask.png'),
                    'scoreboard_image': os.path.join(gfx_dir, 'pallo_scoreboard.png'),
                    'title_image' : os.path.join(gfx_dir, 'title_screen.png'),
                    'loading_image' : os.path.join(gfx_dir, 'penalti_loading.png'),
                    'ball_frames': [os.path.join(gfx_dir, png) for png in ['pallo1_alt.png', 'pallo2_alt.png', 'pallo3_alt.png', 'pallo4_alt.png']],
                    'ball_death_frames': [os.path.join(gfx_dir, png) for png in ['pallo_destroy1.png', 'pallo_destroy2.png', 'pallo_destroy3.png', 'pallo_destroy4.png']],
                    'ball_mask': os.path.join(gfx_dir, 'pallo_mask.png')}
               }


def handle_redraw():
    canvas.blit(active_screen)


audio_dir = os.path.join(cwd, 'audio')
intro_path = os.path.join(audio_dir, 'intro.wav')
intro_music = Sound.open(intro_path)
intro_music.set_volume(2)
intro_music.play(audio.KMdaRepeatForever)

image_paths = grass_field['gfx']
title_screen = graphics.Image.open(image_paths['title_image'])
loading_screen = graphics.Image.open(image_paths['loading_image'])
active_screen = title_screen

canvas = appuifw.Canvas(redraw_callback=handle_redraw)
appuifw.app.screen = 'full'
appuifw.app.body = canvas
canvas.blit(title_screen)

res = appuifw.query(u"Play multiplayer?", 'query')

L = [u"Malmo", u"Espoo"]
track_no = appuifw.popup_menu(L, u"Select a track!")

# intro_music.stop()
canvas.blit(loading_screen)
active_screen = loading_screen
e32.ao_yield()

if track_no == 0 :
  track = grass_field
else :
  track = grass_field_2


if res: w = World.World(track, World.MULTIPLAYER, intro_music)
else: w = World.World(track, World.SINGLEPLAYER, intro_music)
