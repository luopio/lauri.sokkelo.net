
class Atom:
    ''' an object in World that has position and velocity '''
    
    def __init__(self, world, position, radius = 5):
        # Previous position used to calculate velocity (Verlet algorithm)
        self.old_position = self.position = position
        self.moving = True
        
        self.canvas = world.get_dbl_buffer()
        self.world = world
        
        # Radius of point (Used for collisions)
        self.radius = radius
        self.w, self.h = self.canvas.size
        self.speed_x, self.speed_y = 0,0
        self.forced_acceleration_x, self.forced_acceleration_y = 0,0
        self.slowdown_factor = 1
        
        self.active = False


    # Applies a velocity to the atom
    def apply_force(self, dx, dy):
        x, y = self.position
        self.position = x + dx, y + dy
    
    
    def warp_to(self, xy):
        self.old_position = self.position = xy
        

    # Updates the atom
    def update(self):
        if self.moving : 
            # Calculate new position
            if self.slowdown_factor < 1: self.slowdown_factor = 1.0
            # else: self.slowdown_factor /= 2.0
                
            cx, cy = self.position
            ox, oy = self.old_position
            gx, gy = self.world.gravity
            nx, ny = cx + (((cx - ox) + gx) / self.slowdown_factor), cy + (((cy - oy) + gy) / self.slowdown_factor)
            # ix, iy = (cx - ox) + gx, (cy - oy) + gy
            # ix /= self.slowdown_factor
            # iy /= self.slowdown_factor
            # nx, ny = cx + ix, cy + iy
            
            # Confine the atom to the current canvas and apply friction
            #if nx - self.radius < 0:
            #  nx = self.radius
            #  cy += (ny - cy) * 0.5
            #elif nx + self.radius >= self.w:
            #  nx = self.w - 1 - self.radius
            #  cy += (ny - cy) * 0.5
        
            #if ny - self.radius < 0:
            #  ny = self.radius
            #  cx += (nx - cx) * 0.5
            #elif ny + self.radius >= self.h:
            #  ny = self.h - 1 - self.radius
            #  cx += (nx - cx) * 0.5
    
            # Update position variables
            if (nx > 0 and nx < self.world.size[0]) and (ny > 0 and ny < self.world.size[1]):
                self.position = nx, ny
                self.old_position = cx, cy
                self.speed_x = nx - cx
                self.speed_y = ny - cy
            else: 
                self.speed_x = 0
                self.speed_y = 0
                self.old_position = self.position
                # self.world.gravity = 0,0
            
 
    def start(self):
        self.moving = True
        
    
    def stop(self):
        self.moving = True
        