import audio
from audio import Sound
import os, appuifw


# This class is a audio engine of the game!

class Soundtrack:

  def __init__(self):
    fulname = appuifw.app.full_name()
    if fulname.lower().find('python') != -1:
      cwd = 'e:\\python'
    else:
      cwd = os.getcwd()
        
    audio_dir = os.path.join(cwd, 'audio') # assuming audio is under the 'audio' dir in the current working directory
    print "open audio from '%s'" % audio_dir
    intro_path = os.path.join(audio_dir, 'intro.wav')
    print "intro at %s" % intro_path
    self.intro_music = Sound.open(intro_path)
    self.rolling_sound = Sound.open(os.path.join(audio_dir, 'rolling.wav'))
    self.rolling_grass_sound = Sound.open(os.path.join(audio_dir, 'rolling_grass.wav'))
    self.destruction = Sound.open(os.path.join(audio_dir, 'destruction.wav'))
    self.race_begin_sound = Sound.open(os.path.join(audio_dir, 'lap.wav'))
    #self.race_ends_sound = Sound.open(u'e:\\ipallo_audio\race_ends.wav')
    self.lap_advanced = Sound.open(os.path.join(audio_dir, 'lap.wav'))
    self.set_volume(2)
    
  def set_volume(self, vol):
      ''' vol from 0 to 10 '''
      self.__vol = vol
    
  def start_intro_music(self):
    self.intro_music.set_volume( self.__vol )
    self.intro_music.play(audio.KMdaRepeatForever)
    
  def start_game_begin(self):
    self.race_begin_sound.set_volume( self.__vol )
    self.race_begin_sound.play()
    
  def start_rolling(self):
    if self.rolling_sound.state() == audio.EOpen :
      self.rolling_sound.set_volume( self.__vol )
      self.rolling_sound.stop()
      self.rolling_grass_sound.stop()
      self.rolling_sound.set_volume( self.__vol )
      self.rolling_sound.play(audio.KMdaRepeatForever)
    
  def stop_rolling(self):
    if self.rolling_sound.state() == audio.EPlaying :
      self.rolling_sound.stop()
    
  def start_rolling_on_grass(self):
    if self.rolling_grass_sound.state() == audio.EOpen and self.destruction.state() == audio.EOpen:
      self.rolling_sound.stop()
      self.rolling_grass_sound.stop()
      self.rolling_grass_sound.set_volume( self.__vol )
      self.rolling_grass_sound.play(audio.KMdaRepeatForever)
    
  def stop_rolling_on_grass(self):
    if self.rolling_grass_sound.state() == audio.EPlaying :
      self.rolling_grass_sound.stop()
    
  def destruct(self):
    self.stop()
    self.destruction.set_volume( self.__vol )
    self.destruction.play()
    
  def suffered_enough(self):
    if self.destruction.state() == audio.EOpen :
      return True
  
  def stop(self):
    self.intro_music.stop()
    self.rolling_sound.stop()
    self.rolling_grass_sound.stop()
    self.race_begin_sound.stop()
    
  def start_lap_advanced(self):
    self.stop()
    self.lap_advanced.set_volume( self.__vol )
    self.lap_advanced.play()

  def __del__(self):
     self.intro_music.stop()
     
     