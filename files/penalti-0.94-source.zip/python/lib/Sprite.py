import e32, graphics, os
from Atom import Atom
from Soundtrack import Soundtrack
#from audio import Sound

class Sprite(Atom):
    ''' just a simple sprite animation class'''
    
    def __init__(self, framefiles, deathframefiles, mask, world):
        Atom.__init__(self, world, (0, 0), 20)
        print "sprite init"
        self.__cur_frame = 0
        self.__frames = []
        for f in framefiles:
            print "appending normal frame"
            self.__frames.append( graphics.Image.open(f) )
        
        
        self.__deathframes = self.__frames
        # self.__deathframes = []
        # for f in deathframefiles:
        #     print "appending death frame"
        #    self.__deathframes.append( graphics.Image.open(f) )
        
        # self.__mask = graphics.Image.open( mask )
        self.__mask = graphics.Image.new( (30, 29), mode='1' )
        self.__mask.load( mask )
        self.radius = self.__mask.size[0] / 2
        
        self.aotimer = e32.Ao_timer()
        self.__frame_interval = 5
        self.set_framerate(5)
        self.change_frame() # start animation
        
        self.__dead = False
        
        self.__world = world
        self.__canvas = self.__world.get_dbl_buffer()
        self.center_pos = self.world.game_view_size[0] / 2, self.world.game_view_size[1] / 2
        
        
    def draw(self, deltas=(0,0)):
        if self.__dead:
            if self.__cur_frame == len(self.__deathframes):
                self.__cur_frame = 0
            else:
                self.__cur_frame += 1
            self.set_framerate(30)
            self.__canvas.blit( self.__deathframes[0], #FIXME the wierd list index out of range thing 
                            mask=self.__mask, 
                            target=(self.center_pos[0] + deltas[0], self.center_pos[1] + deltas[1])  )
            
        else:
            self.set_framerate( max(0, (1 + abs(self.speed_x) + abs(self.speed_y)) * 2) )
            self.__canvas.blit( self.__frames[self.__cur_frame], 
                                mask=self.__mask, 
                                target=(self.center_pos[0] + deltas[0], self.center_pos[1] + deltas[1])  )
        
    
    def set_framerate(self, fr):
        # self.world.debug_text['fr'] = fr
        if fr:
            if self.__frame_interval > 10 and fr > 0.1:  # if the previous frame interval was huge, update directly
                self.aotimer.cancel()
                self.__frame_interval = 1.0 / fr
                self.change_frame()
            else:
                self.__frame_interval = 1.0 / fr
        else:
            self.__frame_interval = 1000
        # self.world.debug_text['fi'] = self.__frame_interval
        
    
    def bring_alive(self):
        self.__dead = False
        self.__cur_frame = 0
    
    def kill(self):
        self.__cur_frame = 0 
        self.__dead = True
    
    
    def stop(self):
        pass # self.aotimer.cancel()
        
        
    def change_frame(self):
        self.__cur_frame += 1
        if self.__cur_frame == len(self.__frames): self.__cur_frame = 0
        self.aotimer.after( self.__frame_interval, self.change_frame )
        
        
    def set_rotation(self):
        ''' TODO: find proper way of doing this'''
        pass
    
    # Returns true if sprite is only barely moving
    # def is_steady(self) :
    #   self.
    
    
    
    
    
    

if __name__ == '__main__':
    import appuifw, random
    running = True
    canvas = appuifw.Canvas()
    
    class w:
        def get_canvas(self): return canvas
    fake_world = w()
    
    def quit():
        global running
        running = False
        s.stop()
        
    # appuifw.note(u'sprite test', 'info')
    # Set up application
    appuifw.app.title = u"sprite test"
    appuifw.app.screen = "large"
    appuifw.app.body = canvas
    
    frames = ['e:\\python\pallo1.png', 'e:\\python\pallo2.png', 'e:\\python\pallo3.png', 'e:\\python\pallo4.png']
    s = Sprite(frames, 'e:\\python\pallo_mask.png', fake_world)
    
    appuifw.app.exit_key_handler = quit
    
    soundtrack = Soundtrack()
    soundtrack.start_intro_music()
    
    #intro = audio.Sound.open(u'e:\\ipallo_audio\intro.wav')
    #intro.play(3)
    
    while running:
        canvas.clear()
        s.draw()
        s.position = random.random() * 100, random.random() * 100, 
        # s.change_frame()
        e32.ao_sleep(0.5)
        e32.reset_inactivity()
        
    soundtrack.stop()
# 
        