import socket, appuifw
import thread

ap_id = socket.select_access_point()
apo = socket.access_point(ap_id)
apo.start()
MY_IP = apo.ip()

class UDPClient(object):
    
    def __init__(self, world, in_port=21224):
        self.world = world
        print "client running on ip %s" % MY_IP
        self.server_ip = appuifw.query(u'Please give server IP', 'text', u"192.168.1.2")
        self.in_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.out_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.in_socket.bind((MY_IP, in_port))
        self.server_addr = str(self.server_ip), in_port
        self.i_am_server = False
        self.player_number = None
        self.prev_pos = None
    

    def connect_to_server(self):
        connected = False
        # self.in_socket.settimeout(5.0)
        while not connected:
            self.out_socket.sendto('i wanna be a client', self.server_addr)
            appuifw.note(u'Connecting to %s' % self.server_addr[0], 'info')
            print "sent to server at %s" % str(self.server_addr)
            try:
                data, addr = self.in_socket.recvfrom(1024)
                connected = True
            except socket.timeout:
                pass
        
        # self.in_socket.settimeout(None)
        
        # appuifw.note(u'received confirmation: %s' % data, 'info')
        self.my_ip, self.player_number = data.split(':')
        self.player_number = int(self.player_number)
        
        appuifw.note(u'I am player #%s. Waiting for all the players to join...' % (self.player_number + 1), 'info')
        data, addr = self.in_socket.recvfrom(1024)
        self.amount_of_players = int(data)
        # appuifw.note(u'Total players: %s' % self.amount_of_players, 'info')
        return self.my_ip, self.player_number
    
    
        '''
        # next wait for the track division
        data, addr = self.in_socket.recvfrom(1024)
        players = data.split('#')
        self.player_tracks = {}
        self.players = []
        for player_str in players:
            pieces = player_str.split('/')
            player_ip = pieces[0]
            self.players.append(player_ip)
            player_tracks = pieces[1:]
            self.player_tracks[player_ip] = player_tracks
        print "client: received players: %s" % unicode(self.players)
        self.run()
        '''

    
    def send_position(self):
        if self.prev_pos != self.world.ball.position:
            self.out_socket.sendto( str(self.world.ball.position), self.server_addr)
            self.prev_pos = self.world.ball.position
    
    
    def receive_position(self):
        data, addr = self.in_socket.recvfrom(1024)
        # try: 
        pos = eval(data)
        self.world.ball.position = pos
        #except SyntaxError: 
        #    print "udpclient - faulty data received: %s" % data
        
    
    def close(self):
        self.in_socket.close()
        self.out_socket.close()
    
        
if __name__ == '__main__':
    c = UDPClient()
    
