import socket, appuifw
import thread

ap_id = socket.select_access_point()
apo = socket.access_point(ap_id)
apo.start()
MY_IP = apo.ip()

class UDPServer(object):
    
    def __init__(self, world, in_port=21224):
        self.world = world
        self.players = [MY_IP]
        hostname = socket.gethostname()
        self.in_port = in_port
        self.in_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.out_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.in_socket.bind((MY_IP, in_port))
        print "server: running on %s: %s" % (MY_IP, in_port)
        self.my_ip = MY_IP
        self.player_number = 0
        self.prev_pos = None
        
        
    def wait_for_players(self):
        ''' start by waiting for players '''
        wait_more = True
        res = appuifw.query(u"Server IP address is %s. Wait for more players?" % self.my_ip, 'query')                
        if res:
            while wait_more:
                data,addr = self.in_socket.recvfrom(1024)
                appuifw.note(u'Received from %s' % addr[0], 'info')
                print "received from", addr
                if not addr[0] in self.players and addr[0] != '':
                    self.players.append(addr[0])
                    self.out_socket.sendto(addr[0]+':'+str(len(self.players) - 1), (addr[0], self.in_port))
                    res = appuifw.query(u"Found player #%s. Wait for more?" % unicode(len(self.players)), 'query')                
                    if not res: wait_more = False
                else:
                    print "data from already active addr %s received" % addr[0]
        self.amount_of_players = len(self.players)
        self.__send_to_all(self.amount_of_players)
        return self.players
    
    
    def __send_to_all(self, msg, orig_addr=None):
        if not msg: return
        if not orig_addr: orig_addr = (self.my_ip, None)
        for player in self.players:
            if player == '': continue
            # if player == self.my_ip:
            #    self.world.udp_client.notify(self.my_ip, str(msg))
            elif player != orig_addr[0] and player != self.my_ip:
                print "server: sending to %s: %s" % (orig_addr[0], msg)
                # appuifw.note(u'server: sends to %s: %s' %(player, msg), 'info')
                addr = (str(player), 21224)
                self.out_socket.sendto(str(msg), addr)
                # addr = (str(player), 21225)
    
    
    def send_position(self):
        if self.prev_pos != self.world.ball.position:
            self.__send_to_all(str(self.world.ball.position))
            self.prev_pos = self.world.ball.position
    
    
    def receive_position(self):
        data, addr = self.in_socket.recvfrom(1024)
        #try: 
        pos = eval(data)
        self.world.ball.position = pos
        self.__send_to_all(pos, addr)
        #except SyntaxError: 
        #    print "udpserver - faulty data received: %s" % data
    
    
    def close(self):
        self.in_socket.close()
        self.out_socket.close()
    
    
    '''
    def run(self):
        self.running = True
        while self.running:
            data, addr = self.in_socket.recvfrom(1024)
            print "server received from %s: %s" %(addr[0], data)
            self.__send_to_all(data, addr[0])
    
    
    def stop(self):
        self.running = False
    '''
    
    
    
    
if __name__ == '__main__':
    s = UDPServer()
    
