import appuifw, graphics

class UI:
    
    def __init__(self, image_data, world):
        self.numbers = []
        for n in image_data['number_image_paths']:
            # print "num:"
            # print n
            i = graphics.Image.open(n)
            self.numbers.append( i )
        self.number_width = self.numbers[0].size[0]
        self.world = world
        self.canvas = world.get_dbl_buffer()
        self.cur_num = None
        self.caches = {}
        self.caches['0'] = graphics.Image.new((60, 18))
        self.caches['0'].clear((168, 0, 0))
        
        
        
    def blit_number(self, x, y, number):
        number = str(number)
        if number in self.caches:
            self.canvas.blit( self.caches[number], target=(x, y) )
            return 
        
        self.caches[number] = graphics.Image.new((60, 18))
        self.caches[number].clear((168, 0, 0))
        offset = 0
        print 'UI needs to print', number
        
        for char in number:
            if char == '.':
                indx = 10
            else:
                indx = int(char)
            
            self.caches[number].blit( self.numbers[ indx ], target=(offset, 0) )
            offset += self.number_width
            
        self.canvas.blit( self.caches[number], target=(x, y) )
    