import appuifw, e32, graphics, axyz, Sprite, key_codes, audio, time, UI, random, math
from Soundtrack import Soundtrack

# a few game type constants
SINGLEPLAYER = 0
MULTIPLAYER = 1
MULTIPLAYER_RACE = 2 # NOT IMPLEMENTED (yet? ;) )
# a few constants for ball collisions
SAFE = 0
SLOWDOWN = 1
DEATH = 2

C64_COLORS = {'BLACK': (0,0,0), 'WHITE': (255,255,255), 'RED': (168, 0, 0), 'SKY_BLUE': (168, 255, 255), 'MAGENTA': (204, 68, 204),
              'GREEN': (0, 204, 85), 'BLUE': (40, 68, 224), 'YELLOW': (238, 238, 119), 'ORANGE': (221, 136, 85), 'BROWN': (128, 76, 64),
              'SKIN': (255, 168, 144), 'DARK_GRAY': (88, 88, 88), 'GRAY': (152, 148, 152), 'LIGHT_GREEN': (170, 255, 102), 
              'LIGHT_BLUE': (96, 176, 255), 'LIGHT_GRAY': (208, 208, 208)}


class World:
    
    ''' everything revolves around this '''

    def __init__(self, field_data, game_type, intro_music):
        self.field_data = field_data
        self.game_type = game_type
        self.my_turn = True
        if game_type == MULTIPLAYER or game_type == MULTIPLAYER_RACE:
            
            res = appuifw.query(u'Want to be the server?', 'query')
            if res:
                import UDPServer
                self.connection = UDPServer.UDPServer(self)
                self.connection.wait_for_players()
            else:
                import UDPClient
                self.connection = UDPClient.UDPClient(self)
                self.connection.connect_to_server()
            
            if game_type == MULTIPLAYER:
                # divide the tracks among players in an array where PLAYER_IP_ADDR => ARRAY_OF_TRACK_INDEXES
                cur_pl = 0
                self.players_n_tracks = []
                while cur_pl < self.connection.amount_of_players:
                    self.players_n_tracks.append([])
                    cur_pl += 1
                cur_pl = 0
                for t in self.field_data['track_order']:
                    self.players_n_tracks[cur_pl].append(t)
                    cur_pl += 1
                    if cur_pl == self.connection.amount_of_players: cur_pl = 0
                self.my_tracks = self.players_n_tracks[ self.connection.player_number ]
                print "my tracks:", self.my_tracks
                appuifw.note(u'My tracks %s' % self.my_tracks, 'info')
                if self.field_data['track_order'][0] not in self.my_tracks:
                    self.my_turn = False
            else:
                pass
            
        self.image_paths = field_data['gfx']
        self.world_image = graphics.Image.open(self.image_paths['world_image'])
        self.world_image_mask = graphics.Image.open(self.image_paths['world_image_mask'])
        self.scoreboard_image = graphics.Image.open(self.image_paths['scoreboard_image'])
        self.size = self.world_image.size
        
        self.gravity = (0, 0)
        self.bounce = [0, 0]
        self.lastx, self.lasty = 0,0
        self.debug_text = {}
        self.soundtrack = Soundtrack()
        self.cur_checkpoint = 1
        self.lap_time = 0
        self.fastest_lap_time = 0
        
        self.canvas = appuifw.Canvas(event_callback=self.keyboard_event_handler, redraw_callback=self.handle_redraw)
        print "world starting.."
        print ".. starting graphics"
        appuifw.app.screen = 'full'
        appuifw.app.body = self.canvas
        # REAL SIZE OF SCREEN HERE!
        self.death_background = graphics.Image.new( (self.canvas.size[0], self.canvas.size[1] * 2) )
        y = 0
        cur_color = 0
        w = 10
        self.random_death_slowdown_timer = 0
        self.random_death_slowdown_rnd_y = 0
        while y < self.death_background.size[1]:
            color_vals = C64_COLORS[ C64_COLORS.keys()[cur_color] ]
            cur_color += 1
            if cur_color == len(C64_COLORS.keys()): cur_color = 0
            self.death_background.line(((0, y), (self.death_background.size[0], y)), width=w, outline=color_vals)
            y += w
        
        print ".. size:", self.canvas.size
        self.dbl_buffer = graphics.Image.new( self.canvas.size )
        self.laptime_display_y = self.canvas.size[1] - 50
        self.laptime_display_numbers_y = self.laptime_display_y + 18
        
        self.game_view_size = (220, 220)
        self.game_view_padding_left = (self.canvas.size[0] - self.game_view_size[0]) / 2
        self.game_view_padding_top = self.game_view_padding_left 
        
        self.ui = UI.UI(field_data, self)
        
        print ".. creating ball"
        self.ball = Sprite.Sprite(self.image_paths['ball_frames'], self.image_paths['ball_death_frames'], self.image_paths['ball_mask'], self)
        print ".. connecting sensors"
        axyz.connect(self.sensor_event)
        self.ball.start()
        self.ball_is_dead = False
        self.ball.warp_to( self.field_data['starting_position'] )
        self.lap_start_time = time.time()
        print ".. => world started"
        
        intro_music.stop()
        self.soundtrack.start_game_begin()
        
        self.__main_loop()
        

    def sensor_event(self,x,y,z):
        # Calculate acceleration of device
        self.accx, self.accy = x - self.lastx, y - self.lasty
        self.lastx, self.lasty = x, y
        
        # Apply acceleration as direct velocity and current rotation as progressive velocity
        if self.my_turn:
            self.ball.apply_force(self.accx / 20.0, self.accy / 20.0)
            self.gravity = [x / 200.0, y / 200.0]
       


    def __main_loop(self):
        self.running = True
        self.lap_start_time = time.time()
        appuifw.note(u'start the race!', 'info')
        while self.running:
            e32.ao_yield()
            e32.reset_inactivity()
            self.draw()
            
    
    # Draws the world
    def draw(self):
        
        # death animation here
        if self.ball_is_dead:
            self.random_death_slowdown_timer += 1
            if self.random_death_slowdown_timer % 10:
                self.random_death_slowdown_rnd_y = int(random.random() * 100)
            elif self.random_death_slowdown_timer > 998: self.random_death_slowdown_timer = 0
            
            self.dbl_buffer.blit(self.death_background, target=(0, self.random_death_slowdown_rnd_y))
            if self.soundtrack.suffered_enough() :
              self.bring_ball_alive()
        else:
            self.dbl_buffer.clear(0x111111)
        
        # multiplayer stuff
        if self.game_type == MULTIPLAYER:
            was_my_turn = self.my_turn
            game_view = self.__get_game_view_box_multiplayer()
            
            # if we just moved out of our territory, then tell others
            if was_my_turn and not self.my_turn:
                self.connection.send_position()
                # self.debug_text['tsqi'] = 'ne' # str(int(self.ball.position[0]))+','+str(int(self.ball.position[1]))+'(not)'
            elif not was_my_turn and self.my_turn:
                self.ball.warp_to( self.ball.position )
                audio.say('my turn')
            elif self.my_turn:
                # self.debug_text['tsqi'] = 'my' # str(int(self.ball.position[0]))+','+str(int(self.ball.position[1]))+'(my)'
                self.ball.draw((game_view[2], game_view[3]))
                
        
        # singleplayer stuff
        else:
            self.my_turn = True
            game_view = self.__get_game_view_box()
        
        self.dbl_buffer.blit( self.world_image, 
                            target=(self.game_view_padding_top,self.game_view_padding_left, self.game_view_size[0], self.game_view_size[1]), 
                            source=(game_view[0], game_view[1], game_view[0] + self.game_view_size[0], game_view[1] + self.game_view_size[1]))
        
        
        if self.my_turn:
            self.ball.draw((game_view[2], game_view[3]))
        
            
        if self.my_turn and not self.ball_is_dead:
            self.ball.update()
            col_status = self.__collision_detect()
            if col_status == SAFE:
                self.last_safe_ball_position = self.ball.position
                if abs(self.ball.speed_x) > 0.5 or abs(self.ball.speed_y) > 0.5 :
                    self.soundtrack.start_rolling()
                else :
                    self.soundtrack.stop_rolling()
            elif col_status == SLOWDOWN:
                if abs(self.ball.speed_x) > 0.01 or abs(self.ball.speed_y) > 0.01 :
                    self.soundtrack.start_rolling_on_grass()
                else:
                    self.soundtrack.stop_rolling_on_grass()
            elif col_status == DEATH:
                # Do something spectacular because you are dead!
                self.ball_death()

        
        self.__checkpoint_check()
        
        # draw the scoreboard
        self.dbl_buffer.blit( self.scoreboard_image, target=(0, self.laptime_display_y))
        
        self.ui.blit_number(10, self.laptime_display_numbers_y, self.lap_time)
        self.ui.blit_number(150, self.laptime_display_numbers_y, self.fastest_lap_time)
        
        # self.dbl_buffer.text((0, 245), unicode(self.debug_text), 0xff00ff)
        
        self.canvas.blit(self.dbl_buffer)
        
        if not self.my_turn:
            self.connection.receive_position()
            # audio.say('pos')
            # self.debug_text['p'] = u'pos received!'
            
        
    
    
    def __checkpoint_check(self):
        if self.game_type == MULTIPLAYER:
            pass
        elif self.game_type == SINGLEPLAYER:
            x1, y1, x2, y2 = self.field_data['checkpoints'][self.cur_checkpoint]
            if self.point_inside(self.ball.position, (x1, y1, x2, y2)):
                print "checkpoint!"
                #audio.say(str(self.cur_checkpoint))
                self.cur_checkpoint += 1
                if self.cur_checkpoint == len(self.field_data['checkpoints']): 
                    self.cur_checkpoint = 0
                elif self.cur_checkpoint == 1: # we just went through the lap
                    # audio.say('lap')
                    self.soundtrack.start_lap_advanced()
                    self.lap_time = time.time() - self.lap_start_time
                    self.lap_start_time = time.time()
                    if self.lap_time < self.fastest_lap_time or self.fastest_lap_time == 0:
                        self.fastest_lap_time = self.lap_time
        
    
    def ball_death(self):
        self.soundtrack.destruct()
        self.ball_is_dead = True
        self.ball.kill()
        #aotimer = e32.Ao_timer()
        #aotimer.after(2.0, self.bring_ball_alive)
    
    
    def bring_ball_alive(self):
        self.ball_is_dead = False
        self.ball.warp_to(self.last_safe_ball_position )
        self.ball.bring_alive()
    
    
    def point_inside(self, point, box):
        if point[0] > box[0] and point[0] < box[2] and point[1] > box[1] and point[1] < box[3]:
            return True
        return False
        
    
    def __collision_detect(self):
        
        x1 = self.ball.position[0]
        y1 = self.ball.position[1]
        
        #p = self.world_image.getpixel((x1,y1))[0]
        p = self.world_image_mask.getpixel((x1,y1))[0]
        if p[1] > 100 and p[0] + p[2] < 60: # greenish => slow
            self.ball.slowdown_factor = p[1] / 200.0
            return SLOWDOWN
        elif p[0] > 100 and p[1] + p[2] < 60: # reddish => collision
            return DEATH
        
        self.ball.slowdown_factor = 1.0
        return SAFE
                        
        
    
    def __get_game_view_box(self):
        x, y = self.ball.position
        gv_top_x = x - (self.game_view_size[0] / 2)
        gv_top_y = y - (self.game_view_size[1] / 2)
        
        # calculate the offset for the ball from the screen center
        pos_dx, pos_dy = 0, 0
        if gv_top_x < 0: 
            pos_dx = gv_top_x
            gv_top_x = 0
        elif (gv_top_x + self.game_view_size[0]) > self.world_image.size[0]: 
            pos_dx = gv_top_x - (self.world_image.size[0] - self.game_view_size[0])
            gv_top_x = self.world_image.size[0] - self.game_view_size[0]
        
        if gv_top_y < 0: 
            pos_dy = gv_top_y
            gv_top_y = 0
        elif (gv_top_y + self.game_view_size[1]) > self.world_image.size[1]: 
            pos_dy = gv_top_y - (self.world_image.size[1] - self.game_view_size[1])
            gv_top_y = self.world_image.size[1] - self.game_view_size[1]
        
        return gv_top_x, gv_top_y, pos_dx, pos_dy
    
    
    
    def __get_game_view_box_multiplayer(self):
        x, y = self.ball.position
        # sqr_top_x = x - x % self.game_view_size[0] # top corner coords of this view in the world_image 
        # sqr_top_y = y - y % self.game_view_size[1]
        
        track_square_index = math.floor(x / self.game_view_size[0]) + (math.floor(y / self.game_view_size[1]) * self.world_image.size[0] / self.game_view_size[0])  
        track_square_index += 1 # zero index..
        
        # self.debug_text['tqi'] = unicode(track_square_index)
        
        if track_square_index in self.my_tracks: self.my_turn = True
        else: self.my_turn = False
        
        # make sure that players are viewing their own track pieces
        if not self.my_turn:
            # find out if this player has the next or previous piece and then show that
            try: indx = self.field_data['track_order'].index( track_square_index )
            except:
                print "ILLEGAL TRACK SQUARE INDEX: ", track_square_index
                indx = 0
                # self.ball.warp_to(self.field_data['starting_position'])
            
            next_indx = indx + 1
            if next_indx == len(self.field_data['track_order']):
                next_indx = 0
            if self.field_data['track_order'][next_indx] in self.my_tracks:
                # self.debug_text['i'] = u'(n)'
                my_closest_index = next_indx
            else:
                prev_indx = indx - 1
                if prev_indx < 0: 
                    prev_indx = len(self.field_data['track_order']) - 1
                if self.field_data['track_order'][prev_indx] in self.my_tracks:
                    # self.debug_text['i'] = u'(p)'
                    my_closest_index = prev_indx
                else:
                    my_closest_index = indx
                    # self.debug_text['i'] = u'err:'
            
            track_piece_no = self.field_data['track_order'][my_closest_index]
            # self.debug_text['trackno'] = track_piece_no
            views_per_row = self.world_image.size[0] / self.game_view_size[0]
            gv_top_x = (track_piece_no % views_per_row - 1) * self.game_view_size[0]
            gv_top_y = math.floor(track_piece_no / views_per_row) * self.game_view_size[1]
        
        else:
            # self.debug_text['i'] = u'(drivin)' + unicode(track_square_index)
            gv_top_x = int(x / self.game_view_size[0]) * self.game_view_size[0]
            gv_top_y = int(y / self.game_view_size[1]) * self.game_view_size[1]
            
            
        gv_center_x = self.game_view_size[0] / 2
        gv_center_y = self.game_view_size[1] / 2 
        
        # calculate the offset for the ball from the screen center
        pos_dx, pos_dy = (x % self.game_view_size[0] - gv_center_x), (y % self.game_view_size[1] - gv_center_y)
                
        return gv_top_x, gv_top_y, pos_dx, pos_dy, track_square_index
    
    
    
    def keyboard_event_handler(self, event):
        if event['type'] == appuifw.EEventKeyDown: #  and
            # self.stop() 
            if event['scancode'] == key_codes.EScancodeRightSoftkey:
                # appuifw.note(u'quit', 'info')
                self.stop()
            # elif event['scancode'] == key_codes.EScancodeLeftSoftkey:
            else:
                pass
                # self.ball.warp_to(self.field_data['starting_position'])
                # self.bring_ball_alive()
                # pth = 'e:\penalti'+str(time.time())+'.png'
                # res = self.canvas.save(pth)
                # appuifw.note(unicode(res), 'info')
                
            
    
    def handle_redraw(self, event):
        try:
            self.canvas.blit(self.dbl_buffer)
        except:
            pass
             
             
    def get_dbl_buffer(self):
        return self.dbl_buffer  

    
    def stop(self):
        ''' called on exit '''
        self.running = False
        if self.game_type == MULTIPLAYER:
            self.connection.close()
        # appuifw.note(u'quit', 'info')
        # self.soundtrack.stop()
    

if __name__ == '__main__': # JARI REMEMBERS THAT THIS PART OF THE CODE HERE BELOW IS OBSOLETE!!!
    grass_field = {'starting_position': (330, 990),
                   'checkpoints': [(52, 930, 194, 987), (320,938,337,1040),(550, 938, 608, 1040), (683, 735, 732, 822), (490, 386, 602, 425), (783, 333, 820, 430), (989, 127, 1090, 166),
                                   (500, 3, 600, 122), (217, 292, 329, 353), (292, 553, 331, 656), (1, 553, 109, 580)],
                   # 'track_order': [23, 24, 19, 18, 13, 8, 9, 10, 5, 4, 3, 2, 7, 12, 11, 16, 21, 22],
                   
                   'number_image_paths': ['e:\\python\gfx\char_0.png', 'e:\\python\gfx\char_1.png', 'e:\\python\gfx\char_2.png',
                                          'e:\\python\gfx\char_3.png', 'e:\\python\gfx\char_4.png', 'e:\\python\gfx\char_5.png',
                                          'e:\\python\gfx\char_6.png', 'e:\\python\gfx\char_7.png', 'e:\\python\gfx\char_8.png',
                                          'e:\\python\gfx\char_9.png', 'e:\\python\gfx\char_..png'], 
                   
                   # 'track_order' : [22,23,24,17,12,7,8,9,4,3,2,1,6,11,10,15,20,21],
                   'track_order':  [22, 23, 24, 19, 18, 13, 8, 9, 10, 5, 4, 3, 2, 7, 12, 11, 16, 21], 
                   
                   'gfx': { 'world_image': 'e:\\python\gfx\katu_1.png',
                        'scoreboard_image': 'e:\\python\gfx\pallo_scoreboard.png',
                        'ball_frames': ['e:\\python\gfx\pallo1.png', 'e:\\python\gfx\pallo2.png', 'e:\\python\gfx\pallo3.png', 'e:\\python\gfx\pallo4.png'],
                        'ball_death_frames': ['e:\\python\gfx\pallo1.png', 'e:\\python\gfx\pallo2.png', 'e:\\python\gfx\pallo3.png', 'e:\\python\gfx\pallo4.png'],
                        'ball_mask': 'e:\\python\gfx\pallo_mask.png'}
                   }
    #intro screeni pit�is olla t�s� sit?

    res = appuifw.query(u"multiplayer?", 'query')
    if res: w = World(grass_field, MULTIPLAYER)
    else: w = World(grass_field, SINGLEPLAYER)
    